# Fortnite-Drivers-Signed-Selfleak
Some of my old signed drivers English Cat#1111 and cleckzy#1337

To use it put the drivers on your C: and run loaddriver.bat twice, after that you can use it. Refer to the usermode to connect it.
